/*
 * textillate.js
 * http://jschr.github.com/textillate
 * MIT licensed
 *
 * Copyright (C) 2012-2013 Jordan Schroter
 */

(function (jQuery) {
  "use strict";

  function isInEffect (effect) {
    return /In/.test(effect) || jQuery.inArray(effect, jQuery.fn.textillate.defaults.inEffects) >= 0;
  };

  function isOutEffect (effect) {
    return /Out/.test(effect) || jQuery.inArray(effect, jQuery.fn.textillate.defaults.outEffects) >= 0;
  };


  function stringToBoolean(str) {
    if (str !== "true" && str !== "false") return str;
    return (str === "true");
  };

  // custom get data api method
  function getData (node) {
    var attrs = node.attributes || []
      , data = {};

    if (!attrs.length) return data;

    jQuery.each(attrs, function (i, attr) {
      var nodeName = attr.nodeName.replace(/delayscale/, 'delayScale');
      if (/^data-in-*/.test(nodeName)) {
        data.in = data.in || {};
        data.in[nodeName.replace(/data-in-/, '')] = stringToBoolean(attr.nodeValue);
      } else if (/^data-out-*/.test(nodeName)) {
        data.out = data.out || {};
        data.out[nodeName.replace(/data-out-/, '')] =stringToBoolean(attr.nodeValue);
      } else if (/^data-*/.test(nodeName)) {
        data[nodeName.replace(/data-/, '')] = stringToBoolean(attr.nodeValue);
      }
    })

    return data;
  }

  function shuffle (o) {
      for (var j, x, i = o.length; i; j = parseInt(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
      return o;
  }

  function animate (jQueryt, effect, cb) {
    jQueryt.addClass('animated ' + effect)
      .css('visibility', 'visible')
      .show();

    jQueryt.one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {
        jQueryt.removeClass('animated ' + effect);
        cb && cb();
    });
  }

  function animateTokens (jQuerytokens, options, cb) {
    var that = this
      , count = jQuerytokens.length;

    if (!count) {
      cb && cb();
      return;
    }

    if (options.shuffle) jQuerytokens = shuffle(jQuerytokens);
    if (options.reverse) jQuerytokens = jQuerytokens.toArray().reverse();

    jQuery.each(jQuerytokens, function (i, t) {
      var jQuerytoken = jQuery(t);

      function complete () {
        if (isInEffect(options.effect)) {
          jQuerytoken.css('visibility', 'visible');
        } else if (isOutEffect(options.effect)) {
          jQuerytoken.css('visibility', 'hidden');
        }
        count -= 1;
        if (!count && cb) cb();
      }

      var delay = options.sync ? options.delay : options.delay * i * options.delayScale;

      jQuerytoken.text() ?
        setTimeout(function () { animate(jQuerytoken, options.effect, complete) }, delay) :
        complete();
    });
  };

  var Textillate = function (element, options) {
    var base = this
      , jQueryelement = jQuery(element);

    base.init = function () {
      base.jQuerytexts = jQueryelement.find(options.selector);

      if (!base.jQuerytexts.length) {
        base.jQuerytexts = jQuery('<ul class="texts"><li>' + jQueryelement.html() + '</li></ul>');
        jQueryelement.html(base.jQuerytexts);
      }

      base.jQuerytexts.hide();

      base.jQuerycurrent = jQuery('<span>')
        .html(base.jQuerytexts.find(':first-child').html())
        .prependTo(jQueryelement);

      if (isInEffect(options.in.effect)) {
        base.jQuerycurrent.css('visibility', 'hidden');
      } else if (isOutEffect(options.out.effect)) {
        base.jQuerycurrent.css('visibility', 'visible');
      }

      base.setOptions(options);

      base.timeoutRun = null;

      setTimeout(function () {
        base.options.autoStart && base.start();
      }, base.options.initialDelay)
    };

    base.setOptions = function (options) {
      base.options = options;
    };

    base.triggerEvent = function (name) {
      var e = jQuery.Event(name + '.tlt');
      jQueryelement.trigger(e, base);
      return e;
    };

    base.in = function (index, cb) {
      index = index || 0;

      var jQueryelem = base.jQuerytexts.find(':nth-child(' + ((index||0) + 1) + ')')
        , options = jQuery.extend(true, {}, base.options, jQueryelem.length ? getData(jQueryelem[0]) : {})
        , jQuerytokens;

      jQueryelem.addClass('current');

      base.triggerEvent('inAnimationBegin');
      jQueryelement.attr('data-active', jQueryelem.data('id'));

      base.jQuerycurrent
        .html(jQueryelem.html())
        .lettering('words');

      // split words to individual characters if token type is set to 'char'
      if (base.options.type == "char") {
        base.jQuerycurrent.find('[class^="word"]')
            .css({
              'display': 'inline-block',
              // fix for poor ios performance
              '-webkit-transform': 'translate3d(0,0,0)',
              '-moz-transform': 'translate3d(0,0,0)',
              '-o-transform': 'translate3d(0,0,0)',
              'transform': 'translate3d(0,0,0)'
            })
            .each(function () { jQuery(this).lettering() });
      }

      jQuerytokens = base.jQuerycurrent
        .find('[class^="' + base.options.type + '"]')
        .css('display', 'inline-block');

      if (isInEffect(options.in.effect)) {
        jQuerytokens.css('visibility', 'hidden');
      } else if (isOutEffect(options.in.effect)) {
        jQuerytokens.css('visibility', 'visible');
      }

      base.currentIndex = index;

      animateTokens(jQuerytokens, options.in, function () {
        base.triggerEvent('inAnimationEnd');
        if (options.in.callback) options.in.callback();
        if (cb) cb(base);
      });
    };

    base.out = function (cb) {
      var jQueryelem = base.jQuerytexts.find(':nth-child(' + ((base.currentIndex||0) + 1) + ')')
        , jQuerytokens = base.jQuerycurrent.find('[class^="' + base.options.type + '"]')
        , options = jQuery.extend(true, {}, base.options, jQueryelem.length ? getData(jQueryelem[0]) : {})

      base.triggerEvent('outAnimationBegin');

      animateTokens(jQuerytokens, options.out, function () {
        jQueryelem.removeClass('current');
        base.triggerEvent('outAnimationEnd');
        jQueryelement.removeAttr('data-active');
        if (options.out.callback) options.out.callback();
        if (cb) cb(base);
      });
    };

    base.start = function (index) {
      setTimeout(function () {
        base.triggerEvent('start');

        (function run (index) {
          base.in(index, function () {
            var length = base.jQuerytexts.children().length;

            index += 1;

            if (!base.options.loop && index >= length) {
              if (base.options.callback) base.options.callback();
              base.triggerEvent('end');
            } else {
              index = index % length;

              base.timeoutRun = setTimeout(function () {
                base.out(function () {
                  run(index)
                });
              }, base.options.minDisplayTime);
            }
          });
        }(index || 0));
      }, base.options.initialDelay);
    };

    base.stop = function () {
      if (base.timeoutRun) {
        clearInterval(base.timeoutRun);
        base.timeoutRun = null;
      }
    };

    base.init();
  }

  jQuery.fn.textillate = function (settings, args) {
    return this.each(function () {
      var jQuerythis = jQuery(this)
        , data = jQuerythis.data('textillate')
        , options = jQuery.extend(true, {}, jQuery.fn.textillate.defaults, getData(this), typeof settings == 'object' && settings);

      if (!data) {
        jQuerythis.data('textillate', (data = new Textillate(this, options)));
      } else if (typeof settings == 'string') {
        data[settings].apply(data, [].concat(args));
      } else {
        data.setOptions.call(data, options);
      }
    })
  };

  jQuery.fn.textillate.defaults = {
    selector: '.texts',
    loop: false,
    minDisplayTime: 2000,
    initialDelay: 0,
    in: {
      effect: 'fadeInLeftBig',
      delayScale: 1.5,
      delay: 50,
      sync: false,
      reverse: false,
      shuffle: false,
      callback: function () {}
    },
    out: {
      effect: 'hinge',
      delayScale: 1.5,
      delay: 50,
      sync: false,
      reverse: false,
      shuffle: false,
      callback: function () {}
    },
    autoStart: true,
    inEffects: [],
    outEffects: [ 'hinge' ],
    callback: function () {},
    type: 'char'
  };

}(jQuery));
