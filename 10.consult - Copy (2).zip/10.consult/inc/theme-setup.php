 <?php 
 
 register_nav_menus(array(
    'header_menu' => 'Header Menu',
	'footer_menu' => 'Footer Menu',
 )); 
 
 ?> 